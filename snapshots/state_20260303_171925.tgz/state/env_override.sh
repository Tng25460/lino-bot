# Loaded AFTER scripts/env_perf.sh (so it wins)

# Force SELL loop behavior
export SELL_ONLY=1
export TRADER_DRY_RUN=1
export SELL_DRY_RUN=0
export SELL_FORCE_ALL=1

# Make sell_engine tick fast
export SELL_GLOBAL_COOLDOWN_S=1
export SELL_SWAP_MIN_INTERVAL_SEC=0

# IMPORTANT: simulate wrapper outcomes by mint (no Jupiter call)
export SELL_WRAP_SIMULATE_MAP='{
  "Ro11111111111111111111111111111111111111111":"route_fail",
  "Ra11111111111111111111111111111111111111111":"429",
  "In11111111111111111111111111111111111111111":"insufficient"
}'
