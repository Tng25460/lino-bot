from __future__ import annotations

import asyncio
import os
import sys
from typing import Any, Dict, List

# Assure les imports "core.*" et "config.*"
PROJECT_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
from dotenv import load_dotenv
# Auto-load env (API keys, base URLs)
try:
    load_dotenv(os.path.join(PROJECT_ROOT, '.env.real'), override=True)
except Exception:
    pass

if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)

from config import settings
from core.logger import get_logger
from core.wallet import Wallet
from core.risk_checks import RiskChecker
from core.trading import TradingEngine
from core.token_scanner import TokenScanner, ScannerConfig


ASCII_LINO = r"""
██╗     ██╗███╗   ██╗ ██████╗
██║     ██║████╗  ██║██╔═══██╗
██║     ██║██╔██╗ ██║██║   ██║
██║     ██║██║╚██╗██║██║   ██║
███████╗██║██║ ╚████║╚██████╔╝
╚══════╝╚═╝╚═╝  ╚═══╝ ╚═════╝
L I N O   B O T
"""


def _get_float(name: str, default: float) -> float:
    v = os.getenv(name)
    if not v:
        return default
    try:
        return float(v)
    except Exception:
        return default


async def run_loop() -> None:
    logger = get_logger()

    loop = asyncio.get_running_loop()

    def _handle_asyncio_exc(loop, context):
        msg = context.get("message", "asyncio exception")
        exc = context.get("exception")
        logger.error(f"[ASYNCIO] {msg} exc={exc}", exc_info=True)

    loop.set_exception_handler(_handle_asyncio_exc)


    logger.info(f"Bot Lino démarré en mode {settings.MODE}")
    logger.info(ASCII_LINO)

    # MODE=REAL safety: refuse to run without wallet/key material
    if settings.MODE == "REAL":
        # core.wallet loads keypair; keep explicit message for clarity
        kp_path = os.getenv("TRADER_KEYPAIR_PATH", "keypair.json")
        if not os.path.exists(kp_path):
            logger.error("❌ MODE=REAL but keypair missing: %s", kp_path)
            raise SystemExit(2)


    wallet = Wallet()
    logger.info(f"[WALLET] Loaded keypair with pubkey: {wallet.pubkey()}")

    risks = RiskChecker(logger=logger, rpc_url=settings.RPC_URL, mode=settings.MODE)

    engine = TradingEngine(
        wallet=wallet,
        logger=logger,
        positions_file=os.path.join(PROJECT_ROOT, "positions.json"),
        mode=settings.MODE,
    )

    # -------- Scanner --------
    # -------- Jupiter API KEY (ne doit plus bloquer le bot) --------
    # On accepte plusieurs noms pour éviter "on me redemande la clé"
    jup_key = (
        os.getenv("JUPITER_API_KEY")
        or os.getenv("JUP_API_KEY")
        or os.getenv("JUPITER_KEY")
        or getattr(settings, "JUPITER_API_KEY", "")
        or getattr(settings, "JUP_API_KEY", "")
    )
    if not jup_key:
        logger.warning("[WARN] Aucune clé Jupiter trouvée. Le bot continue (scanner DexScreener OK), mais swaps/quotes Jupiter peuvent échouer.")

    cfg = ScannerConfig(
        new_listing_limit=int(getattr(settings, "NEW_LISTING_LIMIT", 5)),
        global_rps=float(getattr(settings, "GLOBAL_RPS", 0.2)),
        max_concurrency=int(getattr(settings, "MAX_CONCURRENCY", 1)),
        min_liquidity_usd=_get_float("MIN_LIQUIDITY_USD", 1000.0),
        max_market_cap_usd=_get_float("MAX_MARKET_CAP_USD", 300000.0),
    )

    scanner = TokenScanner(cfg)
    logger.info(
        f"[Scanner] ✅ limit={getattr(cfg, "new_listing_limit", getattr(cfg, "scan_limit", 30))} rps={cfg.global_rps} conc={cfg.max_concurrency}"
    )

    try:
        while True:
            try:
                overviews: List[Dict[str, Any]] = await scanner.scan_once_async()
                logger.info(f"[DBG_OV] {overviews[:2]}")
                logger.info(f"[Main] overviews reçus: {len(overviews)}")
            except Exception as e:
                logger.error(f"[TokenScanner] scan error: {e}", exc_info=True)
                overviews = []

            # 🔥 TOUJOURS appeler l’engine, même si overviews est vide
            logger.info(
                f"[DBG_MAIN_BEFORE_ENGINE] calling engine.on_overviews n={len(overviews)}"
            )
            await engine.on_overviews(overviews, risks)

            await asyncio.sleep(getattr(settings, "SCAN_INTERVAL_SECONDS", 25))

    except KeyboardInterrupt:
        logger.info("Arrêt demandé (CTRL+C).")
    finally:
        try:
            await scanner.aclose()
        except Exception:
            pass
        logger.info("Bot Lino arrêté.")


def main() -> None:
    logger = get_logger()
    try:
        asyncio.run(run_loop())
    except Exception as e:
        logger.error(f"[MAIN ERROR] {e}", exc_info=True)
        logger.info("Bot Lino arrêté.")


if __name__ == "__main__":
    main()
