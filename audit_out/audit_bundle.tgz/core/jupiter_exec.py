import os
import time
import random
from core.jup_rate_limit import wait_for_slot, note_result
from collections import OrderedDict


JUP_QUOTE_CACHE_TTL_S = float(os.getenv("JUP_QUOTE_CACHE_TTL_S", "4.5"))
JUP_QUOTE_CACHE_MAX   = int(os.getenv("JUP_QUOTE_CACHE_MAX", "256"))
JUP_QUOTE_CACHE_DEBUG = int(os.getenv("JUP_QUOTE_CACHE_DEBUG", "0"))

# in-process cache: key -> (ts, json)
_QUOTE_CACHE = OrderedDict()

def _quote_cache_key(url: str, params: dict) -> str:
    # normalize params (sorted) to stable key
    items = []
    for k in sorted((params or {}).keys()):
        v = params.get(k)
        if isinstance(v, (list, tuple)):
            v = ",".join(map(str, v))
        items.append(f"{k}={v}")
    return url + "?" + "&".join(items)

def _quote_cache_get(key: str):
    if not JUP_QUOTE_CACHE_TTL_S or JUP_QUOTE_CACHE_TTL_S <= 0:
        return None
    now = time.time()
    if key not in _QUOTE_CACHE:
        return None
    ts, val = _QUOTE_CACHE.get(key, (0.0, None))
    if (now - ts) > JUP_QUOTE_CACHE_TTL_S:
        try:
            _QUOTE_CACHE.pop(key, None)
        except Exception:
            pass
        return None
    # LRU bump
    try:
        _QUOTE_CACHE.move_to_end(key, last=True)
    except Exception:
        pass
    return val

def _quote_cache_put(key: str, val):
    if not JUP_QUOTE_CACHE_TTL_S or JUP_QUOTE_CACHE_TTL_S <= 0:
        return
    _QUOTE_CACHE[key] = (time.time(), val)
    try:
        _QUOTE_CACHE.move_to_end(key, last=True)
    except Exception:
        pass
    # evict oldest
    while len(_QUOTE_CACHE) > max(8, JUP_QUOTE_CACHE_MAX):
        try:
            _QUOTE_CACHE.popitem(last=False)
        except Exception:
            break


JUP_429_BACKOFF_BASE_S = float(__import__("os").getenv("JUP_429_BACKOFF_BASE_S", "4"))
JUP_429_BACKOFF_MAX_S  = float(__import__("os").getenv("JUP_429_BACKOFF_MAX_S", "30"))
JUP_429_MAX_RETRIES    = int(__import__("os").getenv("JUP_429_MAX_RETRIES", "5"))

def _sleep_429_backoff(attempt: int) -> None:
    base = JUP_429_BACKOFF_BASE_S * (2 ** max(0, attempt))
    t = min(JUP_429_BACKOFF_MAX_S, base)
    # jitter 0..25%
    t = t * (1.0 + random.random() * 0.25)
    time.sleep(t)

DEBUG_QUOTE = int(os.getenv("DEBUG_QUOTE","0"))

def _dbg_http_fail(tag: str, url: str, status: int, body: str):
    if not DEBUG_QUOTE:
        return
    try:
        print(f"🧨 {tag} HTTP {status} url={url}", flush=True)
        if body:
            b = body.strip()
            print("🧨 body:", (b[:1600] + ("..." if len(b) > 1600 else "")), flush=True)
    except Exception:
        pass
import json
import base64
import aiohttp
from typing import Dict, Any, Optional, List


def _dex_id(x: str) -> str:
    s = (x or '').strip().lower()
    s = s.replace('meteora+dlmm','meteora')
    s = s.replace('pumpfun','pump.fun')
    s = s.replace('pump.fun+amm','pump.fun amm')
    s = s.replace('pumpfun amm','pump.fun amm')
    return s

from solders.keypair import Keypair
from solders.transaction import VersionedTransaction

from core.solana_rpc_async import SolanaRPCAsync


# --- builtins guard: ensure _dex_show always exists (avoid NameError across scopes) ---
import builtins as _builtins
if not hasattr(_builtins, '_dex_show'):
    _builtins._dex_show = lambda x: x
try:
    _builtins._dex_show = globals().get('_dex_show', _builtins._dex_show)
except Exception:
    pass
# --- end builtins guard ---

# Base URL: prefer lite-api by default (no key required)
JUP_BASE = os.getenv("JUP_BASE_URL", "https://lite-api.jup.ag").rstrip("/")
JUP_API_KEY = os.getenv("JUP_API_KEY", "").strip()

SLIPPAGE_BPS = int(os.getenv("JUP_SLIPPAGE_BPS", "250"))
PRIORITY_FEE_MICROLAMPORTS = int(os.getenv("JUP_PRIORITY_FEE_MICROLAMPORTS", "0"))
JUP_TIMEOUT_S = float(os.getenv("JUP_TIMEOUT_S", "15"))
JUP_RETRIES = int(os.getenv("JUP_RETRIES", "3"))

# If SELL_DRY_RUN not explicitly set, inherit TRADER_DRY_RUN
if "SELL_DRY_RUN" in os.environ:
    SELL_DRY_RUN = os.getenv("SELL_DRY_RUN", "1").strip().lower() not in ("0", "false", "no", "off")
else:
    SELL_DRY_RUN = os.getenv("TRADER_DRY_RUN", "0").strip().lower() in ("1", "true", "yes", "on")

# Optional global excludes (comma-separated Jupiter dex names)
JUP_EXCLUDE_DEXES = os.getenv("JUP_EXCLUDE_DEXES", "").strip()

# Map internal dex ids -> Jupiter labels (best-effort)
DEX_LABELS = {
    "raydium": "Raydium",
    "meteora": "Meteora+DLMM",
    "orca": "Orca",
    "orca+v2": "Orca+V2",
    "orca v2": "Orca+V2",

    "pump.fun": "Pump.fun",
    "pumpfun": "Pump.fun",
    "pump.fun amm": "Pump.fun Amm",
    "pumpfun amm": "Pump.fun Amm",
    "pump.fun+amm": "Pump.fun Amm",
    "pump.fun_amm": "Pump.fun Amm",
    "pumpswap": "Pump.fun Amm",
}
def _headers() -> Dict[str, str]:
    # Only attach key when hitting api.jup.ag (Pro gating); lite-api typically doesn't need it.
    h: Dict[str, str] = {}
    if "api.jup.ag" in JUP_BASE and JUP_API_KEY:
        h["x-api-key"] = JUP_API_KEY
    return h

async def _get_json(session: aiohttp.ClientSession, url: str, params: Dict[str, Any]) -> Dict[str, Any]:
    if JUP_QUOTE_CACHE_DEBUG:
        try:
            qs = "&".join([f"{k}={params[k]}" for k in sorted(params.keys())]) if isinstance(params, dict) else ""
        except Exception:
            qs = ""
        print(f"[jup_cache] ENTER url={url} qs={qs[:140]}", flush=True)
    
    last_err = None

    # --- quote-only cache (SAFE) ---
    is_quote = ("/swap/v1/quote" in url)
    cache_key = None
    if is_quote and JUP_QUOTE_CACHE_TTL_S and JUP_QUOTE_CACHE_TTL_S > 0:
        try:
            cache_key = _quote_cache_key(url, params if isinstance(params, dict) else {})
        except Exception:
            cache_key = None
        if cache_key:
            hit = _quote_cache_get(cache_key)
            if hit is not None:
                if JUP_QUOTE_CACHE_DEBUG:
                    print(f"[jup_cache] HIT key={cache_key[:120]}...", flush=True)
                return hit
            if JUP_QUOTE_CACHE_DEBUG:
                print(f"[jup_cache] MISS key={cache_key[:120]}...", flush=True)

    # --- adaptive rate limit gate (quotes only) ---
    if is_quote:
        try:
            wait_for_slot()
        except Exception:
            pass

    for attempt in range(JUP_RETRIES):
        try:
            async with session.get(
                url,
                params=params,
                headers=_headers(),
                timeout=aiohttp.ClientTimeout(total=JUP_TIMEOUT_S),
            ) as resp:
                # 429 rate limit
                if resp.status == 429:
                    try:
                        note_result(False, was_429=True)
                    except Exception:
                        pass
                    ra = resp.headers.get("Retry-After")
                    try:
                        ra_s = float(ra) if ra else None
                    except Exception:
                        ra_s = None
                    if ra_s and ra_s > 0:
                        time.sleep(min(JUP_429_BACKOFF_MAX_S, ra_s))
                    else:
                        _sleep_429_backoff(attempt)
                    continue

                # transient 5xx
                if resp.status in (500, 502, 503, 504):
                    _sleep_429_backoff(attempt)
                    continue

                if resp.status != 200:
                    txt = await resp.text()
                    raise RuntimeError(f"Jupiter GET failed http={resp.status} url={url} body={txt[:300]}")

                val = await resp.json()

                try:

                    note_result(True)

                except Exception:

                    pass
                if cache_key and is_quote:
                    _quote_cache_put(cache_key, val)
                    if JUP_QUOTE_CACHE_DEBUG:
                        print(f"[jup_cache] PUT key={cache_key[:120]}...", flush=True)
                return val

        except Exception as e:
            last_err = e
            # small backoff on network/timeout too
            _sleep_429_backoff(attempt)

    raise RuntimeError(f"Jupiter GET failed after {JUP_RETRIES} tries: {last_err}")

async def _post_json(session: aiohttp.ClientSession, url: str, payload: Dict[str, Any]) -> Dict[str, Any]:
    
    last_err = None
    for attempt in range(JUP_RETRIES):
        try:
            async with session.post(
                url,
                json=payload,
                headers=_headers(),
                timeout=aiohttp.ClientTimeout(total=JUP_TIMEOUT_S),
            ) as resp:
                if resp.status == 429:
                    ra = resp.headers.get("Retry-After")
                    try:
                        ra_s = float(ra) if ra else None
                    except Exception:
                        ra_s = None
                    if ra_s and ra_s > 0:
                        time.sleep(min(JUP_429_BACKOFF_MAX_S, ra_s))
                    else:
                        _sleep_429_backoff(attempt)
                    continue

                if resp.status in (500, 502, 503, 504):
                    _sleep_429_backoff(attempt)
                    continue

                if resp.status != 200:
                    txt = await resp.text()
                    raise RuntimeError(f"Jupiter POST failed http={resp.status} url={url} body={txt[:300]}")

                return await resp.json()

        except Exception as e:
            last_err = e
            _sleep_429_backoff(attempt)

    raise RuntimeError(f"Jupiter POST failed after {JUP_RETRIES} tries: {last_err}")

def _to_labels(allowed_dexes: Optional[List[str]]) -> List[str]:
    if not allowed_dexes:
        return []
    out = []
    for d in allowed_dexes:
        d0 = (d or "").strip().lower()
        if not d0:
            continue
        out.append(DEX_LABELS.get(d0, d0))
    # unique preserve order
    seen = set()
    uniq = []
    for x in out:
        if x in seen:
            continue
        uniq.append(x)
        seen.add(x)
    return uniq

async def jup_build_swap_tx(
    session: aiohttp.ClientSession,
    user_pubkey: str,
    input_mint: str,
    output_mint: str,
    amount_in: int,
    allowed_dexes: Optional[List[str]] = None,
) -> str:
    wait_for_slot()

    qurl = f"{JUP_BASE}/swap/v1/quote"

    params: Dict[str, Any] = {
        "inputMint": input_mint,
        "outputMint": output_mint,
        "amount": str(amount_in),
        "slippageBps": str(SLIPPAGE_BPS),
    }

    # Optional global excludes (comma-separated Jupiter dex names)
    if JUP_EXCLUDE_DEXES:
        params["excludeDexes"] = JUP_EXCLUDE_DEXES

    # IMPORTANT:
    # - Send dex ids in lowercase to Jupiter (NOT labels)
    # - Labels are only for logs
    dex_ids: List[str] = []
    if allowed_dexes:
        for d in allowed_dexes:
            d0 = (d or "").strip().lower()
            if d0:
                dex_ids.append(d0)
        # unique preserve order
        seen = set()
        dex_ids = [_dex_id(d) for d in (allowed_dexes or []) if str(d).strip()]

    if dex_ids:
        # ensure labels always defined (labels are Jupiter dex filter values)
        labels = []
        if allowed_dexes:
            if isinstance(allowed_dexes, (list, tuple)):
                raw = [str(x) for x in allowed_dexes]
            else:
                raw = [str(allowed_dexes)]
            labels = [DEX_LABELS.get(x.strip().lower(), x.strip()) for x in raw if x and x.strip()]
        # build Jupiter dex filter labels (EXACT labels, not lowercase)
        labels = []
        if allowed_dexes:
            if isinstance(allowed_dexes, (list, tuple)):
                raw = [str(x) for x in allowed_dexes]
            else:
                raw = str(allowed_dexes).split(",")
            for x in raw:
                x = (x or "").strip()
                if not x:
                    continue
                labels.append(DEX_LABELS.get(x.lower(), x))
        dex_ids = [_dex_id(d) for d in (allowed_dexes or []) if str(d).strip()]
        pass  # DISABLED: dex filter values mismatch (use routePlan gating instead)
        labels = _to_labels(dex_ids)
        print(f"🧩 jup_quote dex_ids={dex_ids} labels={labels}", flush=True)
    # strict mode is evaluated per-call (env can change between attempts)
    fallback_any = os.getenv("JUP_DEX_FALLBACK_ANY", "0").strip().lower() in ("1","true","yes","on")

    try:
        quote = await _get_json(session, qurl, params=params)
        # --- debug: print route dex labels from quoteResponse ---
        try:
            rp = quote.get('routePlan') or []
            labs = []
            for step in rp:
                si = (step or {}).get('swapInfo') or {}
                lab = si.get('label') or si.get('ammKey') or si.get('market') or ''
                if lab:
                    labs.append(str(lab))
            # unique preserve order
            seen=set(); labs_u=[x for x in labs if not (x in seen or seen.add(x))]
            if labs_u:
                print(f"🧭 routePlan labels={labs_u}", flush=True)

                # --- gate: enforce allowed route labels (STRICT_ONLY) ---
                strict_only = os.getenv("STRICT_ONLY","0").strip().lower() in ("1","true","yes","on")
                allowed = os.getenv("ALLOWED_ROUTE_LABELS","").strip()
                deny_s = os.getenv("DENY_ROUTE_LABELS","").strip()
                allow = [x.strip().lower() for x in allowed.split(",") if x.strip()] if allowed else []
                deny = [x.strip().lower() for x in deny_s.split(",") if x.strip()] if deny_s else []
                mode = os.getenv("ROUTE_GATE_MODE","all").strip().lower()
                if mode not in ("all","any"):
                    mode = "all"
                print(f"🧪 route gate cfg strict_only={strict_only} mode={mode} allow={allow} deny={deny} labs={labs_u}", flush=True)
                
                if strict_only and (allow or deny):
                    matches = []
                    bad = []
                    deny_hits = []
                    for x in (labs_u or []):
                        lx = str(x).strip().lower()
                        if not lx:
                            continue
                        if deny and any(d in lx for d in deny):
                            deny_hits.append(x)
                            continue
                        # allow logic (substring match): "pump.fun" matches "Pump.fun Amm"
                        if allow:
                            if any(a in lx for a in allow):
                                matches.append(x)
                            else:
                                bad.append(x)
                        else:
                            # no allow list -> only deny list active, so it is ok
                            matches.append(x)
                
                    if deny_hits:
                        print(f"⛔ route gate deny_hits={deny_hits} deny={deny} labs={labs_u}", flush=True)
                        raise RuntimeError(f"STRICT_ONLY route gate deny: deny_hits={deny_hits} deny={deny}")
                
                    if allow:
                        print(f"🧪 route gate matches={matches}", flush=True)
                        # mode=any: PASS if at least one allowed label matches
                        if mode == "any" and matches:
                            bad = []
                        if bad:
                            print(f"⛔ STRICT_ONLY route gate BLOCK bad={bad} allow={allow} labs={labs_u}", flush=True)
                            raise RuntimeError(f"STRICT_ONLY route gate: bad_labels={bad} allowed={allow}")
                        else:
                            print(f"✅ STRICT_ONLY route gate PASS allow={allow} labs={labs_u}", flush=True)
        except RuntimeError:
            raise
        except Exception as _e:
            pass
    except Exception as e:
        # If strict mode and dex restriction requested -> propagate
        if dex_ids and not fallback_any:
            raise
        # Otherwise, fall back to ANY route
        if dex_ids:
            print(f"⚠️ jup_quote restricted failed -> fallback ANY. err={e}", flush=True)
            params.pop("dexes", None)
            quote = await _get_json(session, qurl, params=params)
        else:
            raise

    surl = f"{JUP_BASE}/swap/v1/swap"
    body: Dict[str, Any] = {
        "quoteResponse": quote,
        "userPublicKey": user_pubkey,
        "wrapAndUnwrapSol": True,
    }
    if PRIORITY_FEE_MICROLAMPORTS > 0:
        body["prioritizationFeeLamports"] = PRIORITY_FEE_MICROLAMPORTS

    resp = await _post_json(session, surl, body)
    tx_b64 = resp.get("swapTransaction")
    if not tx_b64:
        raise RuntimeError(f"Jupiter swap response missing swapTransaction keys={list(resp.keys())}")
    return tx_b64

async def jup_sign_and_send(
    rpc: SolanaRPCAsync,
    wallet: Keypair,
    tx_b64: str,
) -> str:
    raw = base64.b64decode(tx_b64)
    vtx = VersionedTransaction.from_bytes(raw)
    sig_tx = VersionedTransaction(vtx.message, [wallet])

    if SELL_DRY_RUN:
        return "DRY_RUN_NO_TX_SENT"

    txsig = await rpc.send_transaction(bytes(sig_tx), skip_preflight=False, max_retries=3)
    return txsig

async def jup_buy_exact_in(
    rpc: SolanaRPCAsync,
    wallet: Keypair,
    input_mint: str,
    output_mint: str,
    amount_in: int,
    allowed_dexes: List[str] | None = None,
) -> str:
    user_pubkey = str(wallet.pubkey())
    async with aiohttp.ClientSession() as session:
        tx_b64 = await jup_build_swap_tx(
            session=session,
            user_pubkey=user_pubkey,
            input_mint=input_mint,
            output_mint=output_mint,
            amount_in=amount_in,
            allowed_dexes=allowed_dexes,
        )
    return await jup_sign_and_send(rpc=rpc, wallet=wallet, tx_b64=tx_b64)

async def jup_sell_exact_in(
    rpc: SolanaRPCAsync,
    wallet: Keypair,
    input_mint: str,
    output_mint: str,
    amount_in: int,
    allowed_dexes: List[str] | None = None,
) -> str:
    user_pubkey = str(wallet.pubkey())
    async with aiohttp.ClientSession() as session:
        tx_b64 = await jup_build_swap_tx(
            session=session,
            user_pubkey=user_pubkey,
            input_mint=input_mint,
            output_mint=output_mint,
            amount_in=amount_in,
            allowed_dexes=allowed_dexes,
        )
    return await jup_sign_and_send(rpc=rpc, wallet=wallet, tx_b64=tx_b64)
