from __future__ import annotations

# STRAT_SCORE_V1 helpers
def _sf(x, d=0.0):
    try:
        if x is None: return float(d)
        return float(x)
    except Exception:
        return float(d)

def _si(x, d=0):
    try:
        if x is None: return int(d)
        return int(float(x))
    except Exception:
        return int(d)

def _pct(x):  # expects 0-100 or already fraction; normalize to pct
    v = _sf(x, 0.0)
    if v <= 1.0 and v >= 0.0:
        return v * 100.0
    return v

def strat_gate_and_score(ov: dict, risk: dict | None = None):
    """
    Returns: (ok: bool, score: float, reason: str, dbg: dict)
    ov: overview (dexscreener-like)
    risk: anti-rug output if available
    """
    risk = risk or {}
    dbg = {}

    liq = _sf(ov.get("liquidity_usd") or ov.get("liquidityUSD") or (ov.get("liquidity") or {}).get("usd"), 0.0)
    v5  = _sf(ov.get("vol5m_usd") or ov.get("volume5mUSD") or (ov.get("volume") or {}).get("m5"), 0.0)
    v1h = _sf(ov.get("vol1h_usd") or ov.get("volume1hUSD") or (ov.get("volume") or {}).get("h1"), 0.0)

    ch5 = _sf(ov.get("chg5m_pct") or ov.get("priceChange5m") or (ov.get("priceChange") or {}).get("m5"), 0.0)
    ch1 = _sf(ov.get("chg1h_pct") or ov.get("priceChange1h") or (ov.get("priceChange") or {}).get("h1"), 0.0)

    trades5m = _si(ov.get("trades5m") or (ov.get("txns") or {}).get("m5", {}).get("buys", 0) + (ov.get("txns") or {}).get("m5", {}).get("sells", 0), 0)
    spread = _sf(ov.get("spread_pct") or ov.get("spreadPCT"), 0.0)

    dbg.update({"liq":liq,"v5":v5,"v1h":v1h,"ch5":ch5,"ch1":ch1,"tr5":trades5m,"spread":spread})

    # Hard gates
    if liq < K.MIN_LIQ_USD:
        return False, 0.0, f"liq<{K.MIN_LIQ_USD}", dbg
    if v5 < K.MIN_VOL5M_USD and v1h < K.MIN_VOL1H_USD:
        return False, 0.0, f"vol<min (v5={v5},v1h={v1h})", dbg
    if ch5 < K.MIN_CHG5M_PCT or ch5 > K.MAX_CHG5M_PCT:
        return False, 0.0, f"chg5m_out({ch5})", dbg
    if ch1 < K.MIN_CHG1H_PCT or ch1 > K.MAX_CHG1H_PCT:
        return False, 0.0, f"chg1h_out({ch1})", dbg
    if trades5m and trades5m < K.MIN_TRADES5M:
        return False, 0.0, f"trades5m<{K.MIN_TRADES5M}", dbg
    if spread and spread > K.MAX_SPREAD_PCT:
        return False, 0.0, f"spread>{K.MAX_SPREAD_PCT}", dbg

    # Risk soft gates (if provided)
    top1 = _pct(risk.get("top_holder_pct") or risk.get("top1_pct") or 0.0)
    top10 = _pct(risk.get("top10_pct") or 0.0)
    dbg.update({"top1":top1,"top10":top10})

    risk_pen = 0.0
    if top1 and top1 > K.MAX_TOPHOLDER_PCT:
        risk_pen += (top1 - K.MAX_TOPHOLDER_PCT) / 10.0
    if top10 and top10 > K.MAX_TOP10_PCT:
        risk_pen += (top10 - K.MAX_TOP10_PCT) / 12.0

    # Score (log-ish without log)
    # Liquidity contribution saturates
    liq_s = min(liq / (K.MIN_LIQ_USD*3), 3.0)
    vol_s = min((v5 / K.MIN_VOL5M_USD) + (v1h / K.MIN_VOL1H_USD), 6.0)
    mom_s = min((ch5 / K.MIN_CHG5M_PCT) + (ch1 / K.MIN_CHG1H_PCT), 8.0)

    score = (K.W_LIQ*liq_s) + (K.W_VOL*vol_s) + (K.W_MOM*mom_s) - (K.W_RISK*risk_pen)
    dbg.update({"liq_s":liq_s,"vol_s":vol_s,"mom_s":mom_s,"risk_pen":risk_pen,"score":score})

    if score < K.SCORE_MIN:
        return False, score, f"score<{K.SCORE_MIN}", dbg
    return True, score, "ok", dbg


# STRAT_SCORE_V1
from config import strategy_knobs as K
import logging
from core.decision_trace import trace as decision_trace
from core.alpha_filters import should_skip_buy, score_overview

import json
import os
import time
from typing import Any, Dict, List, Optional, Tuple

from config import settings
import requests
import builtins




def _safe_float(x: Any, default: float = 0.0) -> float:
    try:
        if x is None:
            return default
        return float(x)
    except Exception:
        return default


def _clamp(x: float, lo: float, hi: float) -> float:
    return max(lo, min(hi, x))

def _safe_num(x, default=0.0):
    try:
        if x is None:
            return default
        return float(x)
    except Exception:
        return default

def _score_overview(ov: Dict[str, Any]) -> float:
    """
    Score momentum léger (API-free).
    Utilise si dispo:
      - priceChange_5m (%)
      - volume_5m (USD)
      - buys_5m / sells_5m
      - liquidity_usd
    """
    pc5 = _safe_num(ov.get("priceChange_5m"), 0.0)
    vol5 = _safe_num(ov.get("volume_5m"), 0.0)
    buys = _safe_num(ov.get("buys_5m"), 0.0)
    sells = _safe_num(ov.get("sells_5m"), 0.0)
    liq = _safe_num(ov.get("liquidity_usd"), 0.0)

    import math
    # ratio buys/sells (évite division par 0)
    ratio = buys / max(1.0, sells)

    # Score (simple mais efficace)
    score = (
        1.3 * pc5
        + 0.8 * math.log1p(vol5)
        + 0.6 * math.log1p(buys)
        + 0.4 * (ratio - 1.0) * 10.0
        - 0.2 * math.log1p(1.0 / max(1.0, liq))  # pénalise liquidité trop faible
    )
    return float(score)

def _volatility_from_ov(ov: Dict[str, Any]) -> float:
    """
    Volatilité proxy (en %): max(|pc5|, |pc1h|) si dispo.
    """
    pc5 = abs(_safe_num(ov.get("priceChange_5m"), 0.0))
    pc1 = abs(_safe_num(ov.get("priceChange_1h"), 0.0))
    return float(max(pc5, pc1))




def _market_quality_ok(ov: dict) -> tuple[bool, str]:
    """Filtre anti-junk: bloque les tokens sans activité réelle.
    Utilise ov['data'] (DexScreener) : liquidity, volume.m5, txns.m5.buys/sells
    """
    try:
        data = (ov.get("data") or {})
        liq = float(data.get("liquidity") or 0.0)

        vol = data.get("volume") or {}
        vol_m5 = float(vol.get("m5") or 0.0)

        txns = data.get("txns") or {}
        tx_m5 = txns.get("m5") or {}
        buys = int(tx_m5.get("buys") or 0)
        sells = int(tx_m5.get("sells") or 0)
        total = buys + sells

        # settings.py / env
        MIN_LIQ = float(getattr(settings, "MIN_LIQUIDITY_USD", float(os.getenv("MIN_LIQUIDITY_USD", "15000"))))
        MIN_VOL_M5 = float(getattr(settings, "MIN_VOLUME_M5_USD", float(os.getenv("MIN_VOLUME_M5_USD", "2000"))))
        MIN_TXNS_M5 = int(getattr(settings, "MIN_TXNS_M5_TOTAL", int(os.getenv("MIN_TXNS_M5_TOTAL", "40"))))
        MIN_BUYS_M5 = int(getattr(settings, "MIN_BUYS_M5", int(os.getenv("MIN_BUYS_M5", "15"))))

        if liq < MIN_LIQ:
            return False, f"LOW_LIQ<{MIN_LIQ}"
        if vol_m5 < MIN_VOL_M5:
            return False, f"LOW_VOL_M5<{MIN_VOL_M5}"
        if total < MIN_TXNS_M5:
            return False, f"LOW_TXNS_M5<{MIN_TXNS_M5}"
        if buys < MIN_BUYS_M5:
            return False, f"LOW_BUYS_M5<{MIN_BUYS_M5}"

        return True, "OK"
    except Exception as e:
        return False, f"MQ_ERR:{e}"


class TradingEngine:

    def _recent_sells_path(self) -> str:
        import os
        positions_file = getattr(self, "positions_file", "positions.json")
        base_dir = os.path.dirname(positions_file) or "."
        return os.path.join(base_dir, "recent_sells.json")
    def _load_recent_sells(self) -> None:
        import os, json, time
        try:
            path = self._recent_sells_path()
            if not os.path.exists(path):
                # pas de fichier = ok
                self._recent_sells = getattr(self, "_recent_sells", {}) or {}
                if getattr(self, "logger", None):
                    self.logger.info(f"[COOLDOWN] no recent_sells.json at {path}")
                return

            with open(path, "r", encoding="utf-8") as f:
                data = json.load(f) or {}

            # data attendu: mint -> last_sell_ts (float/int)
            now = time.time()
            cleaned = {}
            for mint, ts in (data or {}).items():
                try:
                    tsf = float(ts)
                    # on garde seulement des timestamps plausibles
                    if tsf > 0 and tsf < now + 3600:
                        cleaned[str(mint)] = tsf
                except Exception:
                    continue

            self._recent_sells = cleaned
            if getattr(self, "logger", None):
                self.logger.info(f"[COOLDOWN] loaded recent sells: {len(cleaned)} from {path}")
        except Exception as e:
            # jamais crasher au boot
            self._recent_sells = getattr(self, "_recent_sells", {}) or {}
            if getattr(self, "logger", None):
                self.logger.warning(f"[COOLDOWN] failed to load recent sells: {e}")
    def _save_recent_sells(self) -> None:
        import os, json
        try:
            path = self._recent_sells_path()
            os.makedirs(os.path.dirname(path) or ".", exist_ok=True)

            tmp = path + ".tmp"
            with open(tmp, "w", encoding="utf-8") as f:
                json.dump(getattr(self, "_recent_sells", {}) or {}, f, indent=2, sort_keys=True)
            os.replace(tmp, path)

            if getattr(self, "logger", None):
                self.logger.info(f"[COOLDOWN] saved recent sells: {len(getattr(self,'_recent_sells',{}) or {})} to {path}")
        except Exception as e:
            if getattr(self, "logger", None):
                self.logger.warning(f"[COOLDOWN] failed to save recent sells: {e}")
    def __init__(self, wallet, logger, positions_file: str, mode: str):
        self._recent_sells = getattr(self, '_recent_sells', {})
        # cooldown persistence (across restarts)
        self._load_recent_sells()
        self.wallet = wallet
        self.logger = logger
        self.positions_file = positions_file or "positions.json"
        self.mode = (mode or "PAPER").upper().strip()

        from core.real_executor import RealExecutor
        from core.paper_executor import PaperExecutor

        self.executor = RealExecutor(wallet, logger) if self.mode == "REAL" else PaperExecutor(wallet, logger)

        # stratégie
        self.sl_pct = float(getattr(settings, "STOP_LOSS_PCT", 0.15))  # -10%
        self.trailing_pct = float(getattr(settings, "TRAILING_FROM_HIGH_PCT", 0.03))  # -10% depuis high
        self._price_log_cache = {}  # mint -> (entry, high, now, ts)

        # anti spam
        self.last_buy_ts_global: float = 0.0
        self.last_buy_ts_by_mint: Dict[str, float] = {}
        self.buy_inflight: set[str] = set()
        self.sell_inflight: set[str] = set()

        # state
        self.positions: Dict[str, Dict[str, Any]] = {}
        self._load_positions()

        self.logger.info(
            "[TradingEngine] Initialisé (mode=%s, SL=%s%%, trailing=%s%% du high). positions_file=%s",
            self.mode,
            int(self.sl_pct * 100),
            int(self.trailing_pct * 100),
            self.positions_file,
        )

    # ---------------- persistence ----------------
    def _load_positions(self) -> None:
        try:
            if os.path.exists(self.positions_file):
                with open(self.positions_file, "r", encoding="utf-8") as f:
                    self.positions = json.load(f) or {}
            else:
                self.positions = {}
        except Exception as e:
            self.logger.error("[POSITIONS] load error: %s", e, exc_info=True)
            self.positions = {}

    def _save_positions(self) -> None:
        try:
            os.makedirs(os.path.dirname(self.positions_file), exist_ok=True)
        except Exception:
            # si positions_file est juste "positions.json" (pas de dossier)
            pass

        tmp = self.positions_file + ".tmp"
        try:
            with open(tmp, "w", encoding="utf-8") as f:
                json.dump(self.positions, f, indent=2, sort_keys=True)
            os.replace(tmp, self.positions_file)
        except Exception as e:
            self.logger.error("[POSITIONS] save error: %s", e, exc_info=True)
            try:
                if os.path.exists(tmp):
                    os.remove(tmp)
            except Exception:
                pass

    # ---------------- helpers ----------------
    def _is_open(self, mint: str) -> bool:
        p = self.positions.get(mint) or {}
        return (p.get("status") == "OPEN")

    def _open_positions(self) -> Dict[str, Dict[str, Any]]:
        return {m: p for m, p in (self.positions or {}).items() if p.get("status") == "OPEN"}

    def _update_high(self, pos: Dict[str, Any], price: float) -> None:
        high = _safe_float(pos.get("high_price"), _safe_float(pos.get("entry_price"), 0.0))
        if price > high:
            pos["high_price"] = price

    def _should_sell(self, pos: Dict[str, Any], price: float) -> Tuple[bool, str]:
        entry = _safe_float(pos.get("entry_price"), 0.0)
        if entry <= 0.0 or price <= 0.0:
            return False, "no_price"

        # Stop/trailing adaptatifs si enregistrés au buy
        sl_pct = float(pos.get("sl_pct")) if pos.get("sl_pct") is not None else float(self.sl_pct)
        tr_pct = float(pos.get("trailing_pct")) if pos.get("trailing_pct") is not None else float(self.trailing_pct)

        # clamp sécurité (évite valeurs absurdes)
        sl_pct = _clamp(sl_pct, 0.01, 0.95)
        tr_pct = _clamp(tr_pct, 0.005, 0.95)

        # --- STOP LOSS ---
        # ex: sl_pct=0.15 => stop à -15%
        if price <= entry * (1.0 - sl_pct):
            return True, "STOP_LOSS"

        # --- TRAILING FROM HIGH (avec activation) ---
        high = _safe_float(pos.get("high_price"), entry)

        act = float(getattr(settings, "TRAILING_ACTIVATION_PCT", 0.10))
        act = _clamp(act, 0.0, 5.0)

        trailing_active = (high >= entry * (1.0 + act))
        if trailing_active and high > 0 and price <= high * (1.0 - tr_pct):
            return True, "TRAILING_FROM_HIGH"

        return False, "hold"

    async def _fetch_price_usd_jupiter(self, mint: str) -> Optional[float]:
        """
        Fetch prix USD via Jupiter (si le scanner ne renvoie pas le mint).
        Supporte JUPITER_API_KEY + base url.
        """
        try:
            import httpx

            base = os.getenv("JUPITER_BASE_URL", getattr(settings, "JUPITER_BASE_URL", "https://api.jup.ag"))
            api_key = os.getenv("JUPITER_API_KEY", getattr(settings, "JUPITER_API_KEY", "")) or ""
            headers = {}
            if api_key:
                headers["x-api-key"] = api_key

            # endpoint "price/v3" (ids)
            url = base.rstrip("/") + "/price/v3"
            params = {"ids": mint, "t": str(time.time_ns())}
            async with httpx.AsyncClient(timeout=10.0, headers=headers) as client:
                r = await client.get(url, params=params)
                r.raise_for_status()
                js = r.json()
                # [JUP_PRICE] debug: show blockId when available
                try:
                    item_dbg = js.get(mint) if isinstance(js, dict) else None
                    bid = (item_dbg or {}).get("blockId") if isinstance(item_dbg, dict) else None
                    if getattr(self, "logger", None):
                        self.logger.info("[JUP_PRICE] mint=%s blockId=%s", mint, bid)
                        # ANTI_STALE_JUP_BLOCKID: si Jupiter renvoie le même blockId trop souvent, fallback DexScreener
                        try:
                            last = getattr(self, "_jup_last_block", {}) or {}
                            same = getattr(self, "_jup_same_count", {}) or {}
                            prev = last.get(mint)
                            if prev is not None and str(prev) == str(bid):
                                same[mint] = int(same.get(mint, 0) or 0) + 1
                            else:
                                same[mint] = 0
                            last[mint] = bid
                            self._jup_last_block = last
                            self._jup_same_count = same
                            # après 2 répétitions (3 ticks identiques), on tente DexScreener
                            if int(same.get(mint, 0) or 0) >= 2:
                                px_ds = float(self._fetch_price_dexscreener(mint) or 0.0)
                                if px_ds > 0:
                                    if getattr(self, "logger", None):
                                        self.logger.info("[PRICE] fallback dexscreener (stale jup) mint=%s px=%s", mint, px_ds)
                                    return px_ds
                        except Exception:
                            pass

                except Exception:
                    pass
                # [JUP_PRICE_V3_PARSE]
                # Jupiter Price v3: réponse = {mint: {usdPrice: ...}}
                try:
                    if isinstance(js, dict) and mint in js and isinstance(js[mint], dict):
                        v = js[mint].get('usdPrice') or js[mint].get('price') or js[mint].get('priceUsd')
                        if v is not None:
                            return float(v)
                except Exception:
                    pass
                # compat ancienne forme (si jamais)
                data = js.get('data') if isinstance(js, dict) else None
                if isinstance(data, dict) and mint in data and isinstance(data[mint], dict):
                    v = data[mint].get('usdPrice') or data[mint].get('price') or data[mint].get('priceUsd')
                    if v is not None:
                        return float(v)
            # formats possibles:
            # { "data": { "<mint>": { "price": 0.123 } } }
            data = js.get("data") or {}
            row = data.get(mint) or {}
            price = row.get("price")
            if price is None:
                # parfois liste/structure différente
                return None
            return float(price)
        except Exception:
            return None

    # ---------------- core loop ----------------
    async def _fetch_dex_txns_m5(self, mint: str) -> int:
        """Retourne buys+sells sur 5m via DexScreener (0 si inconnu)."""
        try:
            url = f"https://api.dexscreener.com/latest/dex/tokens/{mint}"
            async with httpx.AsyncClient(timeout=10.0) as client:
                r = await client.get(url)
                if r.status_code != 200:
                    return 0
                js = r.json() or {}
                pairs = js.get('pairs') or []
                if not pairs:
                    return 0
                # best liquidity
                def liq(p):
                    try:
                        return float((p.get('liquidity') or {}).get('usd') or 0.0)
                    except Exception:
                        return 0.0
                best = max(pairs, key=liq)
                tx = (best.get('txns') or {}).get('m5') or {}
                buys = int(tx.get('buys') or 0)
                sells = int(tx.get('sells') or 0)
                return buys + sells
        except Exception:
            return 0

    async def on_overviews(self, overviews: List[Dict[str, Any]], risk_checker) -> None:
        """
        1) Met à jour / vend les positions (SL / trailing)
           - prix via overviews si dispo
           - sinon fetch Jupiter si position ouverte
        2) Tente un BUY (1 seul max par cycle) si pas déjà en position sur ce mint
        """
        overviews = overviews or []
        self.logger.info("[DBG_ENTER] on_overviews called, n=%s", len(overviews))

        # map mint->price depuis scanner
        price_map: Dict[str, float] = {}
        for ov in overviews:
            reason = should_skip_buy(ov)
            if reason:
                mint = ov.get('mint') or ov.get('token')
                sym = ov.get('symbol')
                sc = score_overview(ov)
                self.logger.info('[SKIP_ALPHA] mint=%s sym=%s score=%.1f reason=%s', mint, sym, sc, reason)
                continue
            mint = ov.get("mint") or ov.get("token") or ov.get("address")
            px = ov.get("price_usd") or ov.get("price")
            if mint and px not in (None, 0, 0.0):
                price_map[str(mint)] = _safe_float(px, 0.0)

        # 1) manage sells
        await self._manage_positions(price_map)

        # 2) buy (au plus 1 par tick)
        await self._maybe_buy(overviews, risk_checker)

        self._print_portfolio()


    def _fetch_price_dexscreener(self, mint: str) -> float:
        """Fallback price via DexScreener. Returns 0.0 if unavailable."""
        try:
            url = f"https://api.dexscreener.com/latest/dex/tokens/{mint}"
            r = requests.get(url, timeout=12)
            if r.status_code != 200:
                return 0.0
            return 0.0
            j = r.json() or {}
            pairs = j.get('pairs') or []
            best_px = 0.0
            best_liq = 0.0
            for pr in pairs:
                try:
                    liq = float(((pr.get('liquidity') or {}).get('usd')) or 0.0)
                    pxs = pr.get('priceUsd')
                    if pxs is None:
                        continue
                    px = float(pxs or 0.0)
                    if px > 0 and liq >= best_liq:
                        best_liq = liq
                        best_px = px
                except Exception:
                    continue
            return float(best_px or 0.0)
        except Exception:
            return 0.0

    async def _manage_positions(self, price_map: Dict[str, float]) -> None:
        opens = self._open_positions()
        if not opens:
            return

        for mint, pos in opens.items():
            # prix: scanner d'abord, sinon Jupiter
            # [PRICE] fallback DexScreener if no scanner/jupiter price
            try:
                sm = str(mint)
                if float(price_map.get(sm) or 0.0) <= 0.0:
                    px_ds = float(self._fetch_price_dexscreener(sm) or 0.0)
                    if px_ds > 0:
                        price_map[sm] = px_ds
                        if getattr(self, 'logger', None):
                            # [PRICE] dedup (avoid duplicate lines)
                            try:
                                _m = str(mint)
                                _entry = float(_safe_float(pos.get('entry_price'), 0.0))
                                _high  = float(_safe_float(pos.get('high_price'), 0.0))
                                _now_value = float(price)
                                _prev = (getattr(self, '_price_log_cache', {}) or {}).get(_m)
                                # prev = (entry, high, now, ts)
                                if (not _prev) or (_prev[0]!=_entry) or (_prev[1]!=_high) or (_prev[2]!=_now) or ((time.time()-float(_prev[3] or 0))>2.0):
                                    self._price_log_cache[_m] = (_entry, _high, _now, time.time())
                                    self.logger.info('[PRICE] fallback dexscreener mint=%s px=%s', sm, px_ds)
                            except Exception:

                                pass
            except Exception as e:
                if getattr(self, 'logger', None):
                    self.logger.warning('[PRICE] fallback error mint=%s err=%s', mint, e)

            price = _safe_float(price_map.get(mint), 0.0)
            if price <= 0.0:
                price = _safe_float(await self._fetch_price_usd_jupiter(mint) or 0.0, 0.0)

            # [PRICE] debug (live)
            try:
                if isinstance(pos, dict):
                    pos['last_price_usd'] = float(price or 0.0)
                    # persist pour voir le prix bouger dans positions.json
                    self.positions[mint] = pos
                    self._save_positions()
                # [PRICE] dedup (avoid duplicate lines)
                try:
                    _m = str(mint)
                    _entry = float(_safe_float(pos.get('entry_price'), 0.0))
                    _high  = float(_safe_float(pos.get('high_price'), 0.0))
                    _now_value = float(price)
                    _prev = (getattr(self, '_price_log_cache', {}) or {}).get(_m)
                    # prev = (entry, high, now, ts)
                    if (not _prev) or (_prev[0]!=_entry) or (_prev[1]!=_high) or (_prev[2]!=_now) or ((time.time()-float(_prev[3] or 0))>2.0):
                        self._price_log_cache[_m] = (_entry, _high, _now, time.time())
                        self.logger.info('[PRICE] mint=%s entry=%s high=%s now=%s', mint, _safe_float(pos.get('entry_price'),0.0), _safe_float(pos.get('high_price'),0.0), price)
                except Exception:
                    self.logger.info('[PRICE] mint=%s entry=%s high=%s now=%s', mint, _safe_float(pos.get('entry_price'),0.0), _safe_float(pos.get('high_price'),0.0), price)

            except Exception as e:
                self.logger.warning('[PRICE] debug failed mint=%s err=%s', mint, e)
            try:
                if isinstance(pos, dict):
                    pos['last_price_usd'] = float(price or 0.0)
                    # persist pour voir le prix bouger dans positions.json
                    self.positions[mint] = pos
                    self._save_positions()
                # [PRICE] dedup (avoid duplicate lines)
                try:
                    _m = str(mint)
                    _entry = float(_safe_float(pos.get('entry_price'), 0.0))
                    _high  = float(_safe_float(pos.get('high_price'), 0.0))
                    _now_value = float(price)
                    _prev = (getattr(self, '_price_log_cache', {}) or {}).get(_m)
                    # prev = (entry, high, now, ts)
                    if (not _prev) or (_prev[0]!=_entry) or (_prev[1]!=_high) or (_prev[2]!=_now) or ((time.time()-float(_prev[3] or 0))>2.0):
                        self._price_log_cache[_m] = (_entry, _high, _now, time.time())
                        self.logger.info('[PRICE] mint=%s entry=%s high=%s now=%s', mint, _safe_float(pos.get('entry_price'),0.0), _safe_float(pos.get('high_price'),0.0), price)
                except Exception:
                    self.logger.info('[PRICE] mint=%s entry=%s high=%s now=%s', mint, _safe_float(pos.get('entry_price'),0.0), _safe_float(pos.get('high_price'),0.0), price)

            except Exception as e:
                self.logger.warning('[PRICE] debug failed mint=%s err=%s', mint, e)
            if price <= 0.0:
                continue
            # [DEAD_MARKET] si 0 trades trop longtemps => exit (plus safe / moins nerveux)
            # - attend un minimum de temps après le buy
            # - nécessite plusieurs ticks consécutifs sans trades
            # - évite les sells instantanés sur markets jeunes/lag
            try:
                no_trades_sec = _safe_float(getattr(settings, 'DEAD_MARKET_NO_TRADES_SECONDS', _safe_float(os.getenv('DEAD_MARKET_NO_TRADES_SECONDS','0'))))
                sell_pct = _safe_float(getattr(settings, 'DEAD_MARKET_SELL_PCT', _safe_float(os.getenv('DEAD_MARKET_SELL_PCT','1.0'))))

                # garde-fous
                min_hold = _safe_float(getattr(settings, 'DEAD_MARKET_MIN_HOLD_SECONDS', _safe_float(os.getenv('DEAD_MARKET_MIN_HOLD_SECONDS','120'))))
                hits_needed = int(_safe_float(getattr(settings, 'DEAD_MARKET_HITS_NEEDED', _safe_float(os.getenv('DEAD_MARKET_HITS_NEEDED','3')))))

                if no_trades_sec and no_trades_sec > 0:
                    now_ts = time.time()
                    buy_ts = _safe_float(pos.get('buy_ts') or pos.get('opened_ts') or 0.0)

                    # on ne check pas trop tôt après l'entrée
                    if buy_ts > 0 and (now_ts - buy_ts) < min_hold:
                        pass
                    else:
                        txns = await self._fetch_dex_txns_m5(str(mint))
                        last_trade_ts = _safe_float(pos.get('last_trade_ts') or 0.0)
                        hits = int(_safe_float(pos.get('no_trades_hits') or 0))

                        if txns > 0:
                            pos['last_trade_ts'] = now_ts
                            pos['no_trades_hits'] = 0
                        else:
                            if last_trade_ts <= 0:
                                pos['last_trade_ts'] = now_ts
                                pos['no_trades_hits'] = 0
                            else:
                                pos['no_trades_hits'] = hits + 1
                                if (now_ts - last_trade_ts) >= no_trades_sec and int(pos.get('no_trades_hits') or 0) >= max(1, hits_needed):
                                    if mint not in self.sell_inflight:
                                        self.sell_inflight.add(mint)
                                        try:
                                            sell_pct2 = _clamp(float(sell_pct), 0.05, 1.0)
                                            self.logger.info('[SELL] %s reason=%s (no trades %.0fs, hits=%s) pct=%.3f',
                                                             mint, 'NO_TRADES_TIMEOUT', (now_ts-last_trade_ts), int(pos.get('no_trades_hits') or 0), sell_pct2)
                                            res = self.executor.sell(mint, pct=sell_pct2)
                                            if hasattr(res, '__await__'):
                                                res = await res
                                            pos['status'] = 'CLOSED'
                                            pos['closed_ts'] = time.time()
                                            pos['exit_price'] = price
                                            pos['exit_reason'] = 'NO_TRADES_TIMEOUT'
                                            self.positions[mint] = pos
                                            self._save_positions()
                                            self.logger.info('[SELL OK] %s reason=%s', mint, 'NO_TRADES_TIMEOUT')
                                            self._recent_sells[mint] = time.time()
                                            self._save_recent_sells()
                                        except Exception as e:
                                            self.logger.error('[SELL ERROR] %s: %s', mint, e, exc_info=True)
                                        finally:
                                            self.sell_inflight.discard(mint)
                                    continue
            except Exception as e:
                self.logger.warning('[DEAD_MARKET] check failed mint=%s err=%s', mint, e)


            # update ATH
            self._update_high(pos, price)

            do_sell, reason = self._should_sell(pos, price)
            if not do_sell:
                continue

            if mint in self.sell_inflight:
                continue

            self.sell_inflight.add(mint)
            try:
                self.logger.info(
                    "[SELL] %s reason=%s entry=%s high=%s now=%s",
                    mint,
                    reason,
                    _safe_float(pos.get("entry_price"), 0.0),
                    _safe_float(pos.get("high_price"), 0.0),
                    price,
                )

                res = self.executor.sell(mint)
                if hasattr(res, "__await__"):
                    res = await res

                pos["status"] = "CLOSED"
                pos["closed_ts"] = time.time()
                pos["exit_price"] = price
                pos["exit_reason"] = reason

                self.positions[mint] = pos
                self._save_positions()

                self.logger.info("[SELL OK] %s reason=%s", mint, reason)
                self._recent_sells[mint] = time.time()
                self._save_recent_sells()
            except Exception as e:
                self.logger.error("[SELL ERROR] %s: %s", mint, e, exc_info=True)
            finally:
                self.sell_inflight.discard(mint)

    async def _maybe_buy(self, overviews: List[Dict[str, Any]], risk_checker) -> None:
        now = time.time()

        # cooldown global
        cooldown_global = _safe_float(getattr(settings, "BUY_COOLDOWN_SECONDS", 0))
        if cooldown_global > 0 and (now - _safe_float(self.last_buy_ts_global or 0.0) < cooldown_global):
            return

        sol_amount = _safe_float(getattr(settings, "BUY_AMOUNT_SOL", 0.0))
        if sol_amount <= 0:
            return

        # Filtres (env/settings)
        min_pc5 = _safe_float(getattr(settings, "MIN_PRICE_CHANGE_5M", _safe_float(os.getenv("MIN_PRICE_CHANGE_5M", "6"))))
        min_vol5 = _safe_float(getattr(settings, "MIN_VOLUME_5M", _safe_float(os.getenv("MIN_VOLUME_5M", "3000"))))
        min_ratio = _safe_float(getattr(settings, "MIN_BUY_SELL_RATIO", _safe_float(os.getenv("MIN_BUY_SELL_RATIO", "1.2"))))
        max_open = int(getattr(settings, "MAX_OPEN_POSITIONS", int(os.getenv("MAX_OPEN_POSITIONS", "2"))))

        # limite positions ouvertes
        if len(self._open_positions()) >= max_open:
            return

        def _passes_filters(ov: Dict[str, Any]) -> bool:
            pc5 = _safe_num(ov.get("priceChange_5m"), 0.0)
            vol5 = _safe_num(ov.get("volume_5m"), 0.0)
            buys = _safe_num(ov.get("buys_5m"), 0.0)
            sells = _safe_num(ov.get("sells_5m"), 0.0)
            ratio = buys / max(1.0, sells)
            if ov.get("priceChange_5m") is None and ov.get("volume_5m") is None:
                return True
            return (pc5 >= min_pc5 and vol5 >= min_vol5 and ratio >= min_ratio)

        # Trie par score
        overviews = sorted((overviews or []), key=_score_overview, reverse=True)

        did_buy = False
        scored = []  # STRAT_SCORE_V1
        for ov in overviews:
            if did_buy:
                break

            if not _passes_filters(ov):
                continue

            mint: Optional[str] = ov.get("mint") or ov.get("token") or ov.get("address")
            price = ov.get("price_usd") or ov.get("price")
            dex = (ov.get("dex_id") or ov.get("dexId") or "").lower().strip()

            if not mint or price in (None, 0, 0.0):
                continue
            mint = str(mint)

        # STRAT_SCORE_V1: pick best candidate
        if not scored:
            return
        scored.sort(key=lambda x: x[0], reverse=True)
        best_score, best_ov, best_risk = scored[0]
        try:
            from core.decision_trace import trace as decision_trace
            m = (best_ov.get('mint') or best_ov.get('outputMint') or best_ov.get('baseToken',{}).get('address') or '').strip()
            sym = (best_ov.get('symbol') or best_ov.get('baseToken',{}).get('symbol') or '').strip()
            decision_trace(m, sym, 'PICK', 'best_score', {'score': best_score})
        except Exception:
            pass
        overviews = [best_ov]
        return  # STOP: end function cleanly (hotfix)
