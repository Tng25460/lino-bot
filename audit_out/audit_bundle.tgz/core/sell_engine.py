import os
SELL_PRICE_MIN_INTERVAL_SEC = float(os.getenv('SELL_PRICE_MIN_INTERVAL_SEC','0.8'))
import sys
import time as _time
import subprocess
import traceback
import time
import re

def _env_float(name: str, default: float) -> float:
    v = os.environ.get(name)
    if v is None or v == "":
        return float(default)
    try:
        return float(v)
    except Exception:
        return float(default)

def _env_int(name: str, default: int) -> int:
    v = os.environ.get(name)
    if v is None or v == "":
        return int(default)
    try:
        return int(float(v))
    except Exception:
        return int(default)


class SellEngine:
    """
    Sell engine autonome (compatible DB actuelle):
    - lit qty_token (fallback qty)
    - exécute src/sell_exec_wrap.py (Jupiter)
    - TP1 / TP2 partiels + hard SL + time stop + trailing
    """

    def __init__(self, db, price_feed, trader=None):
        self._mint_cooldowns = {}  # mint -> unix_ts until when sells are paused
        try:
            import os
            self.SELL_COOLDOWN_JUP_CUSTOM_SEC = int(os.getenv('SELL_COOLDOWN_JUP_CUSTOM_SEC','21600'))
        except Exception:
            self.SELL_COOLDOWN_JUP_CUSTOM_SEC = 21600
        self.db = db
        self.price_feed = price_feed
        self.trader = trader  # ignored (compat)

        # Fractions (0.01 = 1%)
        self.TP1_PCT = float(os.getenv("SELL_TP1_PCT", "0.30"))
        self.TP1_SIZE = float(os.getenv("SELL_TP1_SIZE", "0.35"))
        self.TP2_PCT = float(os.getenv("SELL_TP2_PCT", "0.80"))
        self.TP2_SIZE = float(os.getenv("SELL_TP2_SIZE", "0.35"))

        self.HARD_SL_PCT = -abs(_env_float('HARD_SL_PCT', _env_float('SELL_HARD_SL_PCT', 0.25)))
        self.TRAIL_TIGHT = float(os.getenv("SELL_TRAIL_TIGHT", "0.10"))
        self.TRAIL_WIDE  = float(os.getenv("SELL_TRAIL_WIDE",  "0.20"))

        self.TIME_STOP_SEC = int(os.getenv("SELL_TIME_STOP_SEC", "900"))
        self.TIME_STOP_MIN_PNL = float(os.getenv("SELL_TIME_STOP_MIN_PNL", "0.05"))

        # 429 rate-limit handling (Jupiter lite-api)
        self.SELL_429_COOLDOWN_SEC = int(os.getenv("SELL_429_COOLDOWN_SEC", "90"))
        self.SELL_ROUTE_FAIL_COOLDOWN_SEC = int(os.getenv("SELL_ROUTE_FAIL_COOLDOWN_SEC", "2700"))  # 45min
        # --- runtime cooldown state (required by some paths, incl. simulate-bypass) ---
        # _global_cooldown: unix timestamp until which sells are globally blocked
        # _mint_cooldown: dict mint->unix timestamp until which that mint is blocked
        self._global_cooldown_store = float(getattr(self, "_global_cooldown", 0.0) or 0.0)
        # keep one single dict: alias _mint_cooldown to existing _mint_cooldowns (plural) if present
        if not hasattr(self, "_mint_cooldowns") or getattr(self, "_mint_cooldowns") is None:
            self._mint_cooldowns = {}
        self._mint_cooldown_store = self._mint_cooldowns
        self._mint_sell_cooldown_until = {}
        self.SELL_429_MAX_RETRY = int(os.getenv("SELL_429_MAX_RETRY", "2"))
        self.SELL_429_BACKOFF_SEC = int(os.getenv("SELL_429_BACKOFF_SEC", "20"))
        self._cfg_logged = False
        self._blocked_until = {}  # mint -> ts until which we skip (e.g. no SOL)
        # price feed 429 handling
        self._price_cache = {}       # mint -> (price, ts)
        self._price_429_until = {}   # mint -> ts until which price fetch is on cooldown
        self._price_429_log_ts = {}  # mint -> ts of last [COOLDOWN] log (anti-spam)
        self.PRICE_CACHE_TTL_S = int(os.getenv("PRICE_CACHE_TTL_S", "30"))
        self.PRICE_429_COOLDOWN_S = int(os.getenv("PRICE_429_COOLDOWN_S", "90"))

    def _ui_qty(self, pos) -> float:
        try:
            return float(pos.get("qty_token") or pos.get("qty") or 0.0)
        except Exception:
            return 0.0

    def _entry(self, pos) -> float:
        try:
            return float(pos.get("entry_price") or pos.get("entry_price_usd") or 0.0)
        except Exception:
            return 0.0
    def _onchain_ui_balance_simple(self, mint: str) -> float:
        import os, json, requests
        pub = os.getenv("WALLET_PUBKEY", "").strip()
        if not pub:
            # fallback: try to read pubkey from keypair
            try:
                from solders.keypair import Keypair
                import json as _json
                kp_path = os.getenv("KEYPAIR_PATH", os.getenv("KEYPATH", "/home/tng25/lino/keypair.json"))
                kp = Keypair.from_bytes(bytes(_json.load(open(kp_path))))
                pub = str(kp.pubkey())
            except Exception:
                return 0.0
        rpc = os.getenv("SOLANA_RPC_URL", os.getenv("RPC_URL", "https://api.mainnet-beta.solana.com"))
        payload = {
            "jsonrpc":"2.0","id":1,"method":"getTokenAccountsByOwner",
            "params":[pub, {"mint": mint}, {"encoding":"jsonParsed"}]
        }
        r = requests.post(rpc, json=payload, timeout=20)
        r.raise_for_status()
        j = r.json()
        vals = (j.get("result",{}) or {}).get("value",[]) or []
        tot = 0.0
        for it in vals:
            try:
                ta = it["account"]["data"]["parsed"]["info"]["tokenAmount"]
                tot += float(ta.get("uiAmount") or 0.0)
            except Exception:
                pass
        return float(tot)

    def _clamp_sell_ui(self, mint: str, ui_db: float) -> float:
        """
        Clamp sell ui to on-chain (prevents oversell -> Jupiter simulation 0x1788).
        """
        try:
            ui_on = float(self._onchain_ui_balance_simple(mint) or 0.0)
        except Exception:
            ui_on = 0.0

        if ui_on > 0:
            ui = min(float(ui_db or 0.0), ui_on)
            # safety epsilon (avoid exact dust/rounding)
            ui = ui * 0.995
            if ui < 0: ui = 0.0
            if ui != float(ui_db or 0.0):
                print(f"🧩 CLAMP_SELL_UI mint={mint} db={ui_db} onchain={ui_on} -> {ui}", flush=True)
            return ui

        return float(ui_db or 0.0)


    def _rl_skip_add(self, mint: str, sec: int, reason: str = ""):


        """Fallback RL-skip used by SELL cooldown paths.


        Writes in-memory mint cooldown + state/rl_skip_mints.json best-effort.


        """


        try:


            import time as _t


            now = float(_t.time())


            sec = int(sec or 0)


            if sec < 0:


                sec = 0


            # in-memory cooldown


            try:


                d = getattr(self, "_mint_sell_cooldown_until", None)


                if not isinstance(d, dict):


                    d = {}


                    setattr(self, "_mint_sell_cooldown_until", d)


                d[str(mint)] = now + float(sec)


            except Exception:


                pass


            # persist for debug


            try:


                import os, json


                path = os.path.join("state", "rl_skip_mints.json")


                os.makedirs("state", exist_ok=True)


                try:


                    obj = json.loads(open(path, "r", encoding="utf-8").read())


                    if not isinstance(obj, dict):


                        obj = {}


                except Exception:


                    obj = {}


                obj[str(mint)] = {"until": now + float(sec), "reason": str(reason or ""), "ts": now}


                open(path, "w", encoding="utf-8").write(json.dumps(obj, ensure_ascii=False, indent=2, sort_keys=True))


            except Exception:


                pass


        except Exception:


            return



    def _sell_exec(self, mint: str, ui_amount: float, reason: str) -> str:
        """Run src/sell_exec_wrap.py and return a marker or txsig."""

        # throttle swaps (best-effort)
        try:
            now = time.time()
            last = float(getattr(self, "_last_swap_ts", 0.0) or 0.0)
            min_iv = float(getattr(self, "SELL_SWAP_MIN_INTERVAL_SEC", 0) or 0)
            if min_iv > 0 and now - last < min_iv:
                time.sleep(max(0.0, min_iv - (now - last)))
            self._last_swap_ts = time.time()
        except Exception:
            pass

        # --- SELL_SWAP_MIN_INTERVAL throttle ---
        try:
            _min_iv = float(getattr(self, "SELL_SWAP_MIN_INTERVAL_SEC", 0.0) or 0.0)
            if _min_iv > 0:
                import time as _t
                _now = float(_t.time())
                _last = float(getattr(self, "_last_sell_swap_ts", 0.0) or 0.0)
                _wait = (_last + _min_iv) - _now
                if _wait > 0:
                    print(f"[SELL] throttle sleep_s={_wait:.2f} reason=min_interval", flush=True)
                    _t.sleep(_wait)
                self._last_sell_swap_ts = float(_t.time())
        except Exception:
            pass

        cmd = [
          sys.executable, '-u', 'src/sell_exec_wrap.py',
          '--mint', str(mint),
          '--ui', str(ui_amount),
          '--reason', str(reason),
        ]
        print(f"🧾 SELL cmd={' '.join(cmd)}", flush=True)
        timeout_s = int(getattr(self, "SELL_EXEC_TIMEOUT_SEC", 180) or 180)
        try:
            proc = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout_s)
        except subprocess.TimeoutExpired:
            return "__FAIL__"
        except Exception:
            return "__FAIL__"

        out = (proc.stdout or "")
        err = (proc.stderr or "")
        out_all = (out + "\n" + err).strip()

        # --- unified rc/text marker handling (sell_exec_wrap.py) ---

        lo = (out_all or "").lower()

        rc = int(getattr(proc, "returncode", 0) or 0)
# rc mapping (wrapper): 42=route_fail_0x1788, 43=insufficient_funds, 44=http_429, 45=token_not_tradable
        if "__TOKEN_NOT_TRADABLE__" in (out_all or "") or rc == 45:

            try:

                print(f"[SELL] token_not_tradable -> close_position reason=token_not_tradable mint={mint}", flush=True)

            except Exception:

                pass

            try:

                self.db.close_position(mint, close_reason="token_not_tradable")

            except Exception:

                try:

                    self.db.close_position(mint, reason="token_not_tradable")

                except Exception:

                    pass

            return "__NOT_TRADABLE__"


        if rc == 44 or "__JUP_HTTP_429__" in (out_all or "") or "http=429" in lo or "too many requests" in lo:

            try:

                print("[SELL] jup_http_429 -> global cooldown", flush=True)

            except Exception:

                pass

            try:

                self._global_cooldown_add("sell_429")

            except Exception:

                pass

            return "__JUP_HTTP_429__"


        if rc == 42 or "__ROUTE_FAIL__" in (out_all or "") or "route_fail" in lo or "0x1788" in lo:

            try:

                print(f"[SELL] route_fail -> mint cooldown mint={mint}", flush=True)

            except Exception:

                pass

            try:

                self._mint_cooldown_add(mint, "sell_route_fail")

            except Exception:

                pass

            return "__ROUTE_FAIL__"


        if rc == 43 or "__JUP_INSUFFICIENT_FUNDS__" in (out_all or "") or "insufficient" in lo:

            try:

                print("[SELL] insufficient_funds -> global cooldown", flush=True)

            except Exception:

                pass

            try:

                self._global_cooldown_add("sell_insufficient")

            except Exception:

                pass

            return "__INSUFFICIENT__"


        if "__dust__" in lo or "dust_untradeable" in lo or ("bad request" in lo and "amount=1" in lo):

            return "__DUST__"

        # --- /unified rc/text marker handling ---


        # extract txsig
        mm = re.search(r'\btxsig=([1-9A-HJ-NP-Za-km-z]{40,})\b', out_all)
        if mm:
            return mm.group(1)
        mm = re.search(r'\b(?:signature|sig)=([1-9A-HJ-NP-Za-km-z]{40,})\b', out_all)
        if mm:
            return mm.group(1)

        return "__FAIL__"
    def run_once(self):

        ### FORCE_SELL_ALL_SIM_BYPASS_TOP_V1 ###
        # If wrapper outcomes are simulated, bypass all price/on-chain checks and test cooldown logic safely.
        _sim_map = os.getenv("SELL_WRAP_SIMULATE_MAP", "").strip()
        _force = str(os.getenv("SELL_FORCE_ALL", "0")).lower() in ("1","true","yes","y")
        if _force and _sim_map:
            print("[SELL] FORCE_SELL_ALL simulate-bypass (TOP) enabled", flush=True)
            # fetch open positions robustly across DB adapter variants
            _positions = []
            try:
                if hasattr(self.db, "get_open_positions"):
                    _positions = self.db.get_open_positions()
                elif hasattr(self.db, "open_positions"):
                    _positions = self.db.open_positions()
                elif hasattr(self.db, "list_open_positions"):
                    _positions = self.db.list_open_positions()
                else:
                    _positions = []
            except Exception as _e:
                print(f"[SELL] simulate-bypass: fetch positions failed err={_e}", flush=True)
                _positions = []
    
            try:
                _n = len(_positions)
            except Exception:
                _n = -1
            print(f"[SELL] simulate-bypass: open_positions={_n}", flush=True)
    
            for _pos in (_positions or []):
                try:
                    if hasattr(_pos, "get"):
                        _mint = _pos.get("mint")
                        _qty  = _pos.get("qty_token", 0.0)
                    else:
                        _mint = _pos["mint"]
                        _qty  = _pos.get("qty_token", 0.0) if hasattr(_pos, "get") else _pos[2] if len(_pos)>2 else 0.0
                    try:
                        _qty = float(_qty or 0.0)
                    except Exception:
                        _qty = 0.0
                    if not _mint or _qty <= 0:
                        continue
                    print(f"🧨 FORCE_SELL_ALL(sim) mint={_mint} qty={_qty}", flush=True)
    
                    txsig = self._sell_exec(_mint, _qty, reason="force_sell_all")
    
                    if txsig == "__NOT_TRADABLE__":
                        print(f"[SELL] token_not_tradable -> close_position reason=token_not_tradable mint={_mint}", flush=True)
                        try:
                            self.db.close_position(_mint, close_reason="token_not_tradable")
                        except TypeError:
                            self.db.close_position(_mint, reason="token_not_tradable")
                        continue
    
                    if txsig == "__JUP_HTTP_429__":
                        print(f"[SELL] http_429 -> mint cooldown {int(self.SELL_429_COOLDOWN_SEC)}s mint={_mint}", flush=True)
                        try:
                            self._rl_skip_add(_mint, int(self.SELL_429_COOLDOWN_SEC), reason="sell_http_429")
                        except Exception as _e:
                            print(f"[SELL] rl_skip_add failed (429) err={_e}", flush=True)
                        continue
    
                    if txsig == "__INSUFFICIENT__":
                        print(f"[SELL] insufficient -> mint cooldown {int(self.SELL_429_COOLDOWN_SEC)}s mint={_mint}", flush=True)
                        try:
                            self._rl_skip_add(_mint, int(self.SELL_429_COOLDOWN_SEC), reason="sell_insufficient")
                        except Exception as _e:
                            print(f"[SELL] rl_skip_add failed (insufficient) err={_e}", flush=True)
                        continue
    
                    if txsig == "__ROUTE_FAIL__":
                        print(f"[SELL] route_fail -> mint cooldown {int(self.SELL_ROUTE_FAIL_COOLDOWN_SEC)}s mint={_mint}", flush=True)
                        try:
                            self._rl_skip_add(_mint, int(self.SELL_ROUTE_FAIL_COOLDOWN_SEC), reason="sell_route_fail")
                        except Exception as _e:
                            print(f"[SELL] rl_skip_add failed (route_fail) err={_e}", flush=True)
                        continue
    
                    print(f"[SELL] simulate-bypass: txsig={txsig} mint={_mint}", flush=True)
                except Exception as _e:
                    print(f"[SELL] simulate-bypass loop error={{_e!r}}", flush=True)
                    print("[SELL] simulate-bypass traceback:", flush=True)
                    print(traceback.format_exc(), flush=True)
                    continue
            return
        ### /FORCE_SELL_ALL_SIM_BYPASS_TOP_V1 ###

        only_mint = (os.getenv("SELL_ONLY_MINT", "") or "").strip()
        if only_mint:
            print("🧪 SELL_ONLY_MINT=", only_mint, flush=True)

        # log SELL_* once
        if not self._cfg_logged:
            self._cfg_logged = True
            keys = sorted([k for k in os.environ.keys() if k.startswith("SELL_")])
            snap = {k: os.getenv(k) for k in keys}
            print("🧾 SELL_ENGINE_CFG " + " ".join([k + "=" + str(snap.get(k)) for k in keys]), flush=True)
            want = ("hard", "sl", "tp", "trail", "time_stop")
            for name in sorted(dir(self)):
                ln = name.lower()
                if any(w in ln for w in want):
                    try:
                        v = getattr(self, name)
                        if isinstance(v, (int, float, str, bool)):
                            print("🧾 SELL_ENGINE_ATTR " + name + "=" + str(v), flush=True)
                    except Exception:
                        pass

        now = _time.time()
        positions = self.db.get_open_positions() or []
        ### DBG_POS_LOOP_V3 ###
        try:
            _force = bool(getattr(self, "SELL_FORCE_ALL", False)) or (str(__import__("os").getenv("SELL_FORCE_ALL","0")).strip() in ("1","true","True"))
            print(f"[DBG] fetched positions: n={len(positions)} SELL_FORCE_ALL={_force}", flush=True)
        except Exception as _e:
            print(f"[DBG] fetched positions: failed err={_e}", flush=True)

        print(f"💰 sell_engine: open_positions={len(positions)}", flush=True)

        for pos in positions:
            qty_token = float(getattr(pos, 'qty_token', 0) or 0)
            if qty_token <= 0:
                continue

            try:

                _m = pos.get('mint') if hasattr(pos, 'get') else getattr(pos, 'mint', None)

                _q = pos.get('qty_token') if hasattr(pos, 'get') else getattr(pos, 'qty_token', None)

                print(f"[DBG] loop item mint={_m} qty={_q}", flush=True)

            except Exception as _e:

                print(f"[DBG] loop item print failed err={_e}", flush=True)

            mint = str(pos.get("mint") or "")
            if not mint:
                continue
            if only_mint and mint != only_mint:
                continue
            # cooldown if last attempt failed due to missing SOL fees/rent
            bu = float(self._blocked_until.get(mint, 0) or 0)
            if bu and _time.time() < bu:
                print(f"⏳ SKIP mint={mint} reason=insufficient_funds cooldown_left={int(bu-_time.time())}s", flush=True)
                continue
            try:
                self._handle_one(pos, now)
            except Exception as e:
                print(f"❌ sell_engine error mint={mint}: {e}", flush=True)
                print(traceback.format_exc(), flush=True)

    # --- cooldown helpers (avoid name collisions with dict/float attrs) ---
    def _global_cooldown_add(self, sec: int, reason: str = ""):
        try:
            now = float(__import__('time').time())
            sec = int(sec or 0)
            until = now + max(sec, 0)
            setattr(self, '_global_sell_cooldown_until', until)
            if sec > 0:
                print(f"⏳ GLOBAL SELL cooldown set {sec}s reason={reason}", flush=True)
        except Exception:
            pass

    def _mint_cooldown_add(self, mint: str, reason: str = "", sec: int | None = None):
        """Per-mint cooldown store used by _handle_one guard.
        If sec is None, pick based on reason/env defaults.
        """
        try:
            mint = str(mint or '').strip()
            if not mint:
                return
            now = float(__import__('time').time())
            # choose duration
            if sec is None:
                if 'route' in (reason or '').lower():
                    sec = int(getattr(self, 'SELL_ROUTE_FAIL_COOLDOWN_SEC', 2700) or 2700)
                elif '429' in (reason or '').lower():
                    sec = int(getattr(self, 'SELL_429_COOLDOWN_SEC', 180) or 180)
                else:
                    sec = int(getattr(self, 'SELL_INSUFFICIENT_COOLDOWN_SEC', getattr(self, 'SELL_429_COOLDOWN_SEC', 180)) or 180)
            sec = int(sec or 0)
            store = getattr(self, '_mint_sell_cooldown_until', None)
            if not isinstance(store, dict):
                store = {}
                setattr(self, '_mint_sell_cooldown_until', store)
            until = now + max(sec, 0)
            store[mint] = max(float(store.get(mint, 0.0) or 0.0), until)
            if sec > 0:
                print(f"⏳ SELL mint cooldown set {sec}s reason={reason} mint={mint}", flush=True)
        except Exception:
            pass


    def _get_price_cached(self, mint: str) -> float:
        """Fetch price with 30s in-memory cache and per-mint 429 cooldown.
        Returns 0.0 when price is unavailable (caller should skip the mint).
        Never blocks the sell loop.
        Tags: [SELL][PRICE_429] on 429, [SELL][COOLDOWN] on active cooldown skip.
        """
        now = _time.time()
        _429_until = self._price_429_until
        _cache = self._price_cache
        _log_ts = self._price_429_log_ts
        ttl = float(self.PRICE_CACHE_TTL_S)
        cooldown_s = float(self.PRICE_429_COOLDOWN_S)
        # check active per-mint 429 cooldown
        if now < _429_until.get(mint, 0.0):
            # log at most once per 60s to avoid spam
            if now - _log_ts.get(mint, 0.0) > 60.0:
                left = int(_429_until[mint] - now)
                print(f"[SELL][COOLDOWN] price_429 cooldown active mint={mint} left={left}s", flush=True)
                _log_ts[mint] = now
            cached = _cache.get(mint)
            return float(cached[0]) if cached else 0.0
        # try cache (< TTL seconds old)
        cached = _cache.get(mint)
        if cached and (now - cached[1]) < ttl:
            return float(cached[0])
        # fetch fresh price
        try:
            p = float(self.price_feed.get_price(mint) or 0.0)
            time.sleep(SELL_PRICE_MIN_INTERVAL_SEC)
            if p > 0:
                _cache[mint] = (p, now)
            return p
        except Exception as _err:
            _msg = str(_err)
            if "429" in _msg or "Too Many" in _msg or "rate limit" in _msg.lower():
                _429_until[mint] = now + cooldown_s
                _log_ts[mint] = now
                print(f"[SELL][PRICE_429] 429 on price feed mint={mint} cooldown={int(cooldown_s)}s", flush=True)
                if cached:
                    print(f"[SELL][PRICE_429] using cached price mint={mint} age={int(now-cached[1])}s", flush=True)
                    return float(cached[0])
            return 0.0

    def _handle_one(self, pos, now: float):
        # ===== FORCE SELL TOP LEVEL =====
        if __import__('os').getenv('SELL_FORCE_ALL','0') == '1':
            mint = pos.get('mint') or pos.get('mint') or pos.get('outputMint')
            qty_total = pos.get('qty_token') or pos.get('qty') or pos.get('amount')
            try:
                print(f"🧨 FORCE_TOP mint={mint} qty={qty_total}", flush=True)
            except Exception:
                pass
            if __import__('os').getenv('SELL_DRY_RUN','0') == '1':
                print('🧪 SELL_DRY_RUN=1 -> skip force sell', flush=True)
                return
            txsig = self._sell_exec(mint, qty_total, 'force_sell_all')
            if txsig:
                print(f"✅ SOLD FORCE_TOP txsig={txsig}", flush=True)
                try:
                    self.db.close_position(mint, close_reason='force_sell_all')
                except Exception:
                    pass
            return
        # ===== /FORCE SELL TOP LEVEL =====

        # MINT_COOLDOWN_SKIP
        mint = pos.get('mint') if isinstance(pos, dict) else getattr(pos, 'mint', None)
        # SELL_COOLDOWN_GUARD
        try:
            now = float(__import__("time").time())
            until = float(getattr(self, "_mint_sell_cooldown_until", {}).get(mint, 0.0) or 0.0)
            if until and now < until:
                left = int(until - now)
                print(f"⏳ SELL mint cooldown active left={left}s mint={mint}", flush=True)
                return
        except Exception:
            pass
        if mint and hasattr(self, '_mint_cooldowns'):
            until = self._mint_cooldowns.get(mint, 0)
            if until and now < until:
                print(f"⏸️ SELL_COOLDOWN skip mint={mint} for {int(until-now)}s")
                return
        mint = str(pos.get("mint") or "")
        entry = self._entry(pos)
        qty_total = self._ui_qty(pos)
        entry_ts = float(pos.get("entry_ts") or pos.get("opened_ts") or 0.0)

        price = self._get_price_cached(mint)
        # sanity: if high-water is wildly off (e.g. after pricing fix), reset it
        try:
            _hw = float(pos.get("high_water") or pos.get("max_price") or 0.0)
        except Exception:
            _hw = 0.0
        if price > 0 and _hw > 0 and _hw > price * 50.0:
            print(f"🧯 HW_SANITY_RESET mint={mint} hw={_hw} price={price}", flush=True)
            _hw = price
            # best-effort persist (adapter may expose set_high_water / set_max_price)
            try:
                if hasattr(self.db, "set_high_water"):
                    self.db.set_high_water(mint, _hw)
                if hasattr(self.db, "set_max_price"):
                    self.db.set_max_price(mint, _hw)
            except Exception:
                pass
            # also update local dict if used later
            try:
                pos["high_water"] = _hw
                pos["max_price"] = _hw
            except Exception:
                pass

        if price <= 0:
            return

        if entry <= 0:
            entry = price
            try:
                self.db.update_position(mint, entry_price=entry, entry_price_usd=entry)
            except Exception:
                pass
            pos["entry_price"] = entry
            print(f"🧩 BOOTSTRAP_ENTRY_FROM_PRICE mint={mint} entry={entry}", flush=True)

        pnl = (price - entry) / entry

        # high water
        hw = float(pos.get("high_water") or pos.get("highest_price") or entry)
        if price > hw:
            hw = price
            try:
                self.db.update_position(mint, high_water=hw, highest_price=hw)
            except Exception:
                pass

        tp1 = bool(pos.get("tp1_done"))
        tp2 = bool(pos.get("tp2_done"))

        print(
            "📈 PRICE mint=%s entry=%s price=%s pnl=%.2f%% tp1=%s tp2=%s hw=%s"
            % (mint, entry, price, pnl * 100.0, int(tp1), int(tp2), hw),
            flush=True,
        )

        # HARD SL (sell ALL)
        # FORCE: sell ALL open positions regardless of pnl (test cleanup)
        if os.getenv('SELL_FORCE_ALL', '0') == '1':
            try:
                print(f"🧨 FORCE_SELL_ALL mint={mint} qty={qty_total}", flush=True)
            except Exception:
                pass
            if os.getenv('SELL_DRY_RUN', '0') == '1':
                try:
                    print('🧪 SELL_DRY_RUN=1 -> skip FORCE_SELL_ALL sell', flush=True)
                except Exception:
                    pass
                return
            txsig = self._sell_exec(mint, qty_total, 'force_sell_all')
            if txsig == '__COOLDOWN__':
                return
            if txsig == '__DUST__':
                print(f"[SELL] dust_untradeable -> close in DB mint={mint}", flush=True)
                try:
                    self.db.close_position(mint, close_reason='dust_untradeable', close_price=price)
                except Exception:
                    try:
                        self.db.close_position(mint, reason='dust_untradeable')
                    except Exception:
                        pass
                return
            if not txsig:
                return
            print(f"✅ SOLD FORCE_ALL txsig={txsig}", flush=True)
            # handle not-tradable marker from sell_exec_wrap
            if txsig in ("__TOKEN_NOT_TRADABLE__", "__JUP_HTTP_400__"):
                try:
                    print(f"🧱 not_tradable -> close_position mint={mint}", flush=True)
                except Exception:
                    pass
                try:
                    self.db.close_position(mint, close_reason="not_tradable")
                except Exception as e:
                    try:
                        print(f"[WARN] close_position not_tradable failed: {e}", flush=True)
                    except Exception:
                        pass
                return

            try:
                self.db.close_position(mint, close_reason='force_sell_all', close_price=price)
            except Exception:
                try:
                    self.db.close_position(mint, reason='force_sell_all')
                except Exception:
                    pass
            return

        if pnl <= self.HARD_SL_PCT:
            print(f"🔴 HARD_SL mint={mint} pnl={pnl:.2%}", flush=True)
            if os.getenv("SELL_DRY_RUN", "0") == "1":
                print("🧪 SELL_DRY_RUN=1 -> skip HARD_SL sell", flush=True)
                return
            sell_qty = qty_total
            txsig = self._sell_exec(mint, sell_qty, "hard_sl")
            # markers from _sell_exec / sell_exec_wrap.py
            if txsig == "__JUP_HTTP_429__":
                print(f"[SELL] global cooldown {int(self.SELL_429_COOLDOWN_SEC)}s reason=429", flush=True)
                try:
                    self._global_block_until = float(time.time()) + float(self.SELL_429_COOLDOWN_SEC)
                except Exception:
                    pass
                return
            if txsig == "__INSUFFICIENT__":
                print(f"[SELL] global cooldown {int(self.SELL_429_COOLDOWN_SEC)}s reason=insufficient_funds", flush=True)
                try:
                    self._global_block_until = float(time.time()) + float(self.SELL_429_COOLDOWN_SEC)
                except Exception:
                    pass
                return
            if txsig == "__ROUTE_FAIL__":
                try:
                    print(f"[SELL] route_fail -> mint cooldown {int(self.SELL_ROUTE_FAIL_COOLDOWN_SEC)}s mint={mint}", flush=True)
                except Exception:
                    pass
                try:
                    self._rl_skip_add(mint, int(self.SELL_ROUTE_FAIL_COOLDOWN_SEC), reason="sell_route_fail")
                except Exception:
                    try:
                        self._mint_sell_cooldown_until[mint] = float(time.time()) + float(self.SELL_ROUTE_FAIL_COOLDOWN_SEC)
                    except Exception:
                        pass
                return
            if txsig == "__JUP_HTTP_429__":
                try:
                    print(f"[SELL] http_429 -> mint cooldown {int(self.SELL_429_COOLDOWN_SEC)}s mint={mint}", flush=True)
                except Exception:
                    pass
                try:
                    self._rl_skip_add(mint, int(self.SELL_429_COOLDOWN_SEC), reason="sell_http_429")
                except Exception:
                    try:
                        self._mint_sell_cooldown_until[mint] = float(time.time()) + float(self.SELL_429_COOLDOWN_SEC)
                    except Exception:
                        pass
                return

            if txsig == "__INSUFFICIENT__":
                try:
                    print(f"[SELL] insufficient -> mint cooldown {int(self.SELL_429_COOLDOWN_SEC)}s mint={mint}", flush=True)
                except Exception:
                    pass
                try:
                    self._rl_skip_add(mint, int(self.SELL_429_COOLDOWN_SEC), reason="sell_insufficient")
                except Exception:
                    try:
                        self._mint_sell_cooldown_until[mint] = float(time.time()) + float(self.SELL_429_COOLDOWN_SEC)
                    except Exception:
                        pass
                return
            if txsig == "__DUST__":
                print(f"[SELL] dust_untradeable -> close in DB mint={mint}", flush=True)
                try:
                    self.db.close_position(mint, close_reason="dust_untradeable")
                except Exception:
                    try:
                        self.db.close_position(mint, reason="dust_untradeable")
                    except Exception:
                        pass
                return
            if txsig == '__DUST__':
                # mark closed in DB and continue
                try:
                    self.db.close_position(mint, now, 'dust_untradeable', 0.0)
                except Exception as e:
                    print(f"❌ close dust failed mint={mint} err={e}")
                return
            if _sell_cooldown_active():
                try:
                    print("[SELL] cooldown active after sell attempt -> stop run_once", flush=True)
                except Exception:
                    pass
                return

            if not txsig:
                return
            print(f"✅ SOLD HARD_SL txsig={txsig}", flush=True)
            try:
                self.db.close_position(mint, close_reason="hard_sl", close_price=price)
            except Exception:
                pass
            return

        # TIME STOP (sell ALL)  (condition: age > TIME_STOP_SEC AND pnl < TIME_STOP_MIN_PNL)
        if entry_ts > 0 and (now - entry_ts) > self.TIME_STOP_SEC and pnl < self.TIME_STOP_MIN_PNL:
            print(f"⏱️ TIME_STOP mint={mint} pnl={pnl:.2%}", flush=True)
            if os.getenv("SELL_DRY_RUN", "0") == "1":
                print("🧪 SELL_DRY_RUN=1 -> skip TIME_STOP sell", flush=True)
                return
            sell_qty = qty_total
            # TIME_STOP_GUARD: only sell if pnl >= min pnl
            if pnl < self.TIME_STOP_MIN_PNL:
                print(f"⏱️ TIME_STOP skip: pnl {pnl:.2%} < min {self.TIME_STOP_MIN_PNL:.2%}")
                return
            txsig = self._sell_exec(mint, sell_qty, "time_stop")
            if txsig == '__DUST__':
                # mark closed in DB and continue
                try:
                    self.db.close_position(mint, now, 'dust_untradeable', 0.0)
                except Exception as e:
                    print(f"❌ close dust failed mint={mint} err={e}")
                return
            if not txsig:
                return
            print(f"✅ SOLD TIME_STOP txsig={txsig}", flush=True)
            try:
                self.db.close_position(mint, close_reason="time_stop", close_price=price)
            except Exception:
                pass
            return

        # TP1
        if (not tp1) and pnl >= self.TP1_PCT:
            sell_qty = qty_total * float(self.TP1_SIZE)
            if sell_qty <= 0:
                print(f"⏭️ TP1 SKIP qty<=0 mint={mint}", flush=True)
                return
            print(f"🟢 TP1 mint={mint} qty={sell_qty}", flush=True)
            if os.getenv("SELL_DRY_RUN", "0") == "1":
                print("🧪 SELL_DRY_RUN=1 -> skip TP1 sell", flush=True)
                return
            txsig = self._sell_exec(mint, sell_qty, "tp1")
            if txsig == "__COOLDOWN__":
                return
            if txsig == "__COOLDOWN__":
                return
            if txsig == '__DUST__':
                # mark closed in DB and continue
                try:
                    self.db.close_position(mint, now, 'dust_untradeable', 0.0)
                except Exception as e:
                    print(f"❌ close dust failed mint={mint} err={e}")
                return
            if not txsig:
                return
            print(f"✅ SOLD TP1 txsig={txsig}", flush=True)
            try:
                self.db.mark_tp1(mint)
            except Exception:
                pass
            return

        # TP2
        if tp1 and (not tp2) and pnl >= self.TP2_PCT:
            sell_qty = qty_total * float(self.TP2_SIZE)
            if sell_qty <= 0:
                print(f"⏭️ TP2 SKIP qty<=0 mint={mint}", flush=True)
                return
            print(f"🟢 TP2 mint={mint} qty={sell_qty}", flush=True)
            if os.getenv("SELL_DRY_RUN", "0") == "1":
                print("🧪 SELL_DRY_RUN=1 -> skip TP2 sell", flush=True)
                return
            txsig = self._sell_exec(mint, sell_qty, "tp2")
            if txsig == "__COOLDOWN__":
                return
            if txsig == "__COOLDOWN__":
                return
            if txsig == '__DUST__':
                # mark closed in DB and continue
                try:
                    self.db.close_position(mint, now, 'dust_untradeable', 0.0)
                except Exception as e:
                    print(f"❌ close dust failed mint={mint} err={e}")
                return
            if not txsig:
                return
            print(f"✅ SOLD TP2 txsig={txsig}", flush=True)
            try:
                self.db.mark_tp2(mint)
            except Exception:
                pass
            return

        # TRAIL (sell ALL)
        trail = self.TRAIL_WIDE if tp2 else self.TRAIL_TIGHT
        stop_price = hw * (1 - trail)
        if hw > 0 and price <= stop_price:
            print(f"🟠 TRAIL_STOP mint={mint} price={price} stop={stop_price} hw={hw}", flush=True)
            if os.getenv("SELL_DRY_RUN", "0") == "1":
                print("🧪 SELL_DRY_RUN=1 -> skip TRAIL sell", flush=True)
                return
            sell_qty = qty_total
            txsig = self._sell_exec(mint, sell_qty, "trailing_stop")
            if txsig == '__DUST__':
                # mark closed in DB and continue
                try:
                    self.db.close_position(mint, now, 'dust_untradeable', 0.0)
                except Exception as e:
                    print(f"❌ close dust failed mint={mint} err={e}")
                return
            if not txsig:
                return
            print(f"✅ SOLD TRAIL txsig={txsig}", flush=True)
            try:
                self.db.close_position(mint, close_reason="trailing_stop", close_price=price)
            except Exception:
                pass
            return


# ---- Robust SELL exec controls (added by patch_sell_engine_safe.py)
SELL_SUBPROCESS_TIMEOUT_S = float(os.getenv("SELL_SUBPROCESS_TIMEOUT_S", "25"))
SELL_GLOBAL_COOLDOWN_S = float(os.getenv("SELL_GLOBAL_COOLDOWN_S", "180"))

# Global cooldown timestamp (unix seconds) to avoid hammering sells when SOL is low
_sell_cooldown_until = 0.0

def _now():
    return time.time()

def _sell_cooldown_active() -> bool:
    global _sell_cooldown_until
    return _now() < _sell_cooldown_until

def _sell_cooldown_set(reason: str):
    global _sell_cooldown_until
    _sell_cooldown_until = _now() + SELL_GLOBAL_COOLDOWN_S
    try:
        print(f"[SELL] global cooldown {SELL_GLOBAL_COOLDOWN_S:.0f}s reason={reason}")
    except Exception:
        pass

def _is_insufficient_funds_blob(blob: str) -> bool:
    if not blob:
            return ""
    b = blob.lower()
    # common markers: your own tag + typical simulation / custom program errors
    # 0x1788 observed in your logs -> treat as "insufficient SOL for fees/rent/ATA"
    hits = [
        "jup_insufficient_funds",
        "insufficient funds",
        "insufficient lamports",
        "insufficient balance",
        "custom program error: 0x1788",
        "0x1788",
        "insufficient funds for rent",
        "accountnotfound",
        "could not find account",
    ]
    return any(h in b for h in hits)
