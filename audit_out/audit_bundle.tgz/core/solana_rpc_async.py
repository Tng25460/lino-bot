from __future__ import annotations

import asyncio
import time
from dataclasses import dataclass
from typing import Any, Dict, Optional

import aiohttp

TOKEN_PROGRAM_ID = "TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA"
TOKEN_2022_PROGRAM_ID = "TokenzQdBNbLqP5VEhdkAS6EPFLC1PHnBqCXEpPxuEb"


@dataclass
class RpcResponseError(Exception):
    message: str
    data: Any = None

    def __str__(self) -> str:
        if self.data is None:
            return self.message
        return f"{self.message} | data={self.data}"


class SolanaRPCAsync:
    """
    Minimal async JSON-RPC client for Solana.
    - timeouts
    - RPS throttling
    - concurrency limit
    - retry/backoff on 429
    """

    def __init__(
        self,
        rpc_url: str,
        *,
        timeout_s: float = 20.0,
        rps: float = 3.0,
        max_concurrency: int = 4,
        max_retries: int = 6,
        backoff_base_s: float = 0.35,
        backoff_cap_s: float = 6.0,
    ) -> None:
        self.rpc_url = rpc_url
        self.timeout_s = float(timeout_s)
        self.rps = float(rps)
        self._min_interval = 1.0 / self.rps if self.rps > 0 else 0.0
        self._last_call = 0.0
        self._sem = asyncio.Semaphore(max(1, int(max_concurrency)))
        self._session: Optional[aiohttp.ClientSession] = None

        self.max_retries = int(max_retries)
        self.backoff_base_s = float(backoff_base_s)
        self.backoff_cap_s = float(backoff_cap_s)

        self._method_cooldown_s = {
            "getTokenLargestAccounts": 0.6,
            "getProgramAccounts": 0.8,
        }

    async def _get_session(self) -> aiohttp.ClientSession:
        if self._session is None or self._session.closed:
            timeout = aiohttp.ClientTimeout(total=self.timeout_s)
            self._session = aiohttp.ClientSession(timeout=timeout)
        return self._session


    async def send_transaction(self, tx_bytes: bytes, skip_preflight: bool = False, max_retries: int = 3) -> str:
        """
        Send a signed transaction (raw bytes) via JSON-RPC sendTransaction.
        Returns the transaction signature string.
        """
        import base64

        if not isinstance(tx_bytes, (bytes, bytearray)):
            raise TypeError(f"tx_bytes must be bytes, got {type(tx_bytes)}")

        b64 = base64.b64encode(bytes(tx_bytes)).decode("ascii")

        opts = {
            "encoding": "base64",
            "skipPreflight": bool(skip_preflight),
            "maxRetries": int(max_retries),
        }

        # JSON-RPC: sendTransaction([<base64_tx>, <opts>])
        return await self.call("sendTransaction", [b64, opts])


    async def close(self) -> None:
        if self._session and not self._session.closed:
            await self._session.close()

    async def aclose(self) -> None:
        await self.close()

    async def _throttle(self, method: str) -> None:
        if self._min_interval > 0:
            now = time.monotonic()
            wait = (self._last_call + self._min_interval) - now
            if wait > 0:
                await asyncio.sleep(wait)
            self._last_call = time.monotonic()

        extra = self._method_cooldown_s.get(method, 0.0)
        if extra > 0:
            await asyncio.sleep(extra)

    @staticmethod
    def _is_429(err: Any) -> bool:
        try:
            return isinstance(err, dict) and int(err.get("code", 0)) == 429
        except Exception:
            return False

    async def call(self, method: str, params: list) -> Any:
        async with self._sem:
            sess = await self._get_session()
            payload = {"jsonrpc": "2.0", "id": 1, "method": method, "params": params}

            attempt = 0
            while True:
                await self._throttle(method)
                try:
                    async with sess.post(self.rpc_url, json=payload) as resp:
                        j = await resp.json(content_type=None)

                    if "error" in j and j["error"]:
                        err = j["error"]
                        if self._is_429(err) and attempt < self.max_retries:
                            sleep_s = min(self.backoff_cap_s, self.backoff_base_s * (2**attempt))
                            sleep_s += (attempt % 3) * 0.07
                            await asyncio.sleep(sleep_s)
                            attempt += 1
                            continue
                        raise RpcResponseError(f"RPC error on {method}", err)

                    return j.get("result")

                except aiohttp.ClientError:
                    if attempt < self.max_retries:
                        sleep_s = min(self.backoff_cap_s, self.backoff_base_s * (2**attempt))
                        await asyncio.sleep(sleep_s)
                        attempt += 1
                        continue
                    raise

    async def get_account_info(self, pubkey: str, *, encoding: str = "jsonParsed") -> Optional[Dict[str, Any]]:
        res = await self.call("getAccountInfo", [pubkey, {"encoding": encoding}])
        if not isinstance(res, dict):
            return None
        return res.get("value")

    async def get_token_largest_accounts(self, mint: str) -> Dict[str, Any]:
        res = await self.call("getTokenLargestAccounts", [mint])
        return res if isinstance(res, dict) else {}

    async def get_token_supply(self, mint: str) -> Dict[str, Any]:
        res = await self.call("getTokenSupply", [mint])
        return res if isinstance(res, dict) else {}
